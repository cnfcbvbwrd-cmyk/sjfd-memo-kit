// SJFD Monthly CA Memo generator - matches City of San Jose Memorandum format
// Usage: node build_memo.js data.json output.docx
const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell,
  WidthType, AlignmentType, BorderStyle, ShadingType, VerticalAlign
} = require('docx');

const data = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const outPath = process.argv[3];

const NAVY = '2C3E5A';
const GRAY_HDR = 'E7E8E8';
const LT_BLUE = 'D9E1F2';
const BORDER_GRAY = 'BFBFBF';
const FONT = 'Arial';
const CONTENT_W = 10080; // letter width 12240 - 2x1080 margins

const noBorder = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
const noBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder,
  insideHorizontal: noBorder, insideVertical: noBorder };
const thin = { style: BorderStyle.SINGLE, size: 4, color: BORDER_GRAY };

function run(text, opts = {}) {
  return new TextRun({ text, font: FONT, size: opts.size || 18, bold: !!opts.bold,
    color: opts.color || '000000', italics: !!opts.italics });
}
function para(children, opts = {}) {
  return new Paragraph({ children, alignment: opts.align,
    spacing: { before: opts.before ?? 0, after: opts.after ?? 0, line: opts.line, lineRule: 'auto' },
    border: opts.border });
}
function heading(text, opts = {}) {
  return new Paragraph({
    children: [run(text, { bold: true, size: 21, color: NAVY })],
    spacing: { before: opts.before ?? 160, after: opts.after ?? 50 },
    border: opts.noRule ? undefined :
      { bottom: { style: BorderStyle.SINGLE, size: 12, color: NAVY, space: 2 } }
  });
}
function cell(children, opts = {}) {
  return new TableCell({
    children, width: { size: opts.w, type: WidthType.DXA },
    borders: opts.borders || noBorders,
    shading: opts.shade ? { type: ShadingType.CLEAR, fill: opts.shade } : undefined,
    verticalAlign: VerticalAlign.CENTER,
    margins: { top: opts.pad ?? 30, bottom: opts.pad ?? 30, left: 60, right: 60 },
    columnSpan: opts.span
  });
}

const children = [];

// ---- Letterhead ----
children.push(new Paragraph({
  children: [new ImageRun({ type: 'png', data: fs.readFileSync('letterhead.png'),
    transformation: { width: 622, height: 100 } })],
  spacing: { after: 100 }
}));

// ---- TO / FROM / SUBJECT / DATE ----
const hdrW = [900, 3900, 1000, 4280];
function hdrRow(l1, v1, l2, v2) {
  return new TableRow({ children: [
    cell([para([run(l1, { bold: true })], { align: AlignmentType.RIGHT })], { w: hdrW[0] }),
    cell([para([run(v1)])], { w: hdrW[1] }),
    cell([para([run(l2, { bold: true })], { align: AlignmentType.RIGHT })], { w: hdrW[2] }),
    cell([para([run(v2)])], { w: hdrW[3] })
  ]});
}
children.push(new Table({
  columnWidths: hdrW, width: { size: CONTENT_W, type: WidthType.DXA }, borders: noBorders,
  rows: [ hdrRow('TO:', data.to, 'FROM:', data.from),
          hdrRow('SUBJECT:', data.subject, 'DATE:', data.date) ]
}));

// ---- rule above SHIFT ASSIGNMENTS ----
children.push(para([run('', {})], {
  before: 80, after: 0,
  border: { bottom: { style: BorderStyle.SINGLE, size: 14, color: NAVY, space: 1 } }
}));
children.push(heading('SHIFT ASSIGNMENTS', { noRule: true, before: 100 }));

// ---- Shift table ----
const sw = [1250, 1350, 1400, 1750, 4330];
const shiftHdr = new TableRow({ children:
  ['Date', 'Time', 'Apparatus', 'Battalion Chief', 'Shift Notes / Significant Events'].map((t, i) =>
    cell([para([run(t, { bold: true, color: 'FFFFFF' })], { align: AlignmentType.CENTER })],
      { w: sw[i], shade: NAVY, borders: { top: thin, bottom: thin, left: thin, right: thin }, pad: 45 }))
});
const shiftRows = data.shifts.map(s => new TableRow({ children:
  [s.date, s.time, s.apparatus, s.bc, s.notes].map((t, i) =>
    cell([para([run(t || '')], { align: i === 4 ? AlignmentType.LEFT : AlignmentType.CENTER })],
      { w: sw[i], borders: { top: thin, bottom: thin, left: thin, right: thin }, pad: 40 }))
}));
children.push(new Table({ columnWidths: sw, width: { size: CONTENT_W, type: WidthType.DXA },
  rows: [shiftHdr, ...shiftRows] }));

// ---- INCIDENT TOTALS ----
children.push(heading('INCIDENT TOTALS'));
const iw = [3250, 1150, 780, 3550, 1350];
const hInside = { top: thin, bottom: thin, left: noBorder, right: noBorder };
const incHdr = new TableRow({ children: [
  cell([para([run('Category', { bold: true, size: 16, color: '595959' })], { align: AlignmentType.CENTER })], { w: iw[0], shade: GRAY_HDR, borders: hInside }),
  cell([para([run('Count', { bold: true, size: 16, color: '595959' })], { align: AlignmentType.CENTER })], { w: iw[1], shade: GRAY_HDR, borders: hInside }),
  cell([para([run('')])], { w: iw[2], borders: noBorders }),
  cell([para([run('Category', { bold: true, size: 16, color: '595959' })], { align: AlignmentType.CENTER })], { w: iw[3], shade: GRAY_HDR, borders: hInside }),
  cell([para([run('Count', { bold: true, size: 16, color: '595959' })], { align: AlignmentType.CENTER })], { w: iw[4], shade: GRAY_HDR, borders: hInside })
]});
const leftCats = [['EMS Calls','ems'],['Structure Fires','structure'],['Vehicle Fires','vehicle'],['MVCs','mvc'],
  ['Rescue Responses','rescue'],['Fire Alarms','alarm'],['Outside Fires','outside'],['Trash Fires','trash']];
const rightCats = [['High Rise Fires','highrise'],['Vegetation Fires','vegetation'],['Gas Investigations','gas'],
  ['Smoke Investigations','smoke'],['Public Service','public'],['Lift Assists','lift'],['Wires Down','wires'],['Fuel Spills','fuel']];
const incRows = leftCats.map(([lc, lk], i) => {
  const [rc, rk] = rightCats[i];
  return new TableRow({ children: [
    cell([para([run(lc)])], { w: iw[0], borders: hInside }),
    cell([para([run(String(data.counts[lk]), { bold: true, color: NAVY })], { align: AlignmentType.CENTER })], { w: iw[1], borders: hInside }),
    cell([para([run('')])], { w: iw[2], borders: noBorders }),
    cell([para([run(rc)])], { w: iw[3], borders: hInside }),
    cell([para([run(String(data.counts[rk]), { bold: true, color: NAVY })], { align: AlignmentType.CENTER })], { w: iw[4], borders: hInside })
  ]});
});
children.push(new Table({ columnWidths: iw, width: { size: CONTENT_W, type: WidthType.DXA }, rows: [incHdr, ...incRows] }));

// total incidents line with navy rule on top
children.push(para(
  [run('TOTAL INCIDENTS:   ', { bold: true }), run(String(data.counts.total), { bold: true, size: 22, color: NAVY })],
  { align: AlignmentType.RIGHT, before: 40, after: 60,
    border: { top: { style: BorderStyle.SINGLE, size: 12, color: NAVY, space: 2 } } }
));

// shifts worked row - shaded value cell
const swW = [5040, 5040];
children.push(new Table({ columnWidths: swW, width: { size: CONTENT_W, type: WidthType.DXA }, borders: noBorders, rows: [
  new TableRow({ children: [
    cell([para([run('Shifts Worked This Month:', { bold: true })])], { w: swW[0] }),
    cell([para([run(String(data.shiftsWorked), { bold: true })], { align: AlignmentType.CENTER })], { w: swW[1], shade: LT_BLUE })
  ]})
]}));

// target solutions / task book
const tsW = [2000, 3040, 2000, 3040];
children.push(new Table({ columnWidths: tsW, width: { size: CONTENT_W, type: WidthType.DXA }, borders: noBorders, rows: [
  new TableRow({ children: [
    cell([para([run('Target Solutions:', { bold: true })])], { w: tsW[0] }),
    cell([para([run(data.targetSolutions)])], { w: tsW[1] }),
    cell([para([run('CA Task Book:', { bold: true })])], { w: tsW[2] }),
    cell([para([run(data.taskBook)])], { w: tsW[3] })
  ]})
]}));

// ---- SIGNIFICANT EVENTS ----
children.push(heading('SIGNIFICANT EVENTS'));
children.push(para([run(data.significantEvents)], { after: 60, line: 252 }));

// ---- TRAINING & ACTIVITIES ----
children.push(heading('TRAINING & ACTIVITIES'));
children.push(para([run(data.training)], { after: 60, line: 252 }));

// ---- EVALUATION SUMMARY ----
children.push(heading('EVALUATION SUMMARY'));
children.push(para([run(data.narrative)], { after: 80, line: 252 }));
children.push(para([run('Policy Study Notes:  ', { bold: true }), run(data.policyNotes)], { after: 60 }));

// ---- signature ----
children.push(para([run('Respectfully submitted,')], { before: 200, after: 300 }));
children.push(para([run(data.signature, { bold: true })]));

const doc = new Document({
  styles: { default: { document: { run: { font: FONT, size: 18 } } } },
  sections: [{
    properties: { page: {
      size: { width: 12240, height: 15840 },
      margin: { top: 780, bottom: 720, left: 1080, right: 1080 }
    }},
    children
  }]
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(outPath, buf);
  console.log('wrote', outPath);
});
