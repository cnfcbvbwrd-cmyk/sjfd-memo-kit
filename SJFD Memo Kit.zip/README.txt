SJFD MEMO KIT
=============
Contents:
- build_memo.js    Generates the City of San Jose memo docx. Usage: node build_memo.js data.json output.docx
                   Requires letterhead.png in the same directory.
- letterhead.png   Official San Jose Memorandum letterhead banner (extracted from the approved memo format).
- sample_data.json Complete JSON schema example (June 2026). Every field shown is required.
- README.txt       This file.

Do not edit build_memo.js unless the department format changes. The layout, colors, and
letterhead placement are locked to the approved memo format.
